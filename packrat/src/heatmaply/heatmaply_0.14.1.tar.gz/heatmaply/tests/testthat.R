library(testthat)
library(heatmaply)

test_check("heatmaply")





# library(heatmaply)
# test_package("heatmaply")
# test_dir("tests\\testthat")
