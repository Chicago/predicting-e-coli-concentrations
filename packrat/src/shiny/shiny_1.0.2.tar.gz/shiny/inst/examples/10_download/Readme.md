We can add a download button to the UI using `downloadButton()`, and write
the content of the file in `downloadHandler()` in `server.R`. See [the
tutorial](http://rstudio.github.io/shiny/tutorial/#downloads) for more
details.
